const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { DatabaseSync } = require("node:sqlite");

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const DB_FILE = process.env.DB_FILE || path.join(ROOT, "biso-trader.sqlite");
const LEGACY_DATA = path.join(ROOT, "data.json");
const sessions = new Map();
const rate = new Map();

if (process.versions.node.split(".")[0] < 22) {
  console.error("Biso Trader v6 nécessite Node.js 22+ (node:sqlite).");
  process.exit(1);
}

const db = new DatabaseSync(DB_FILE);
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, nom TEXT NOT NULL, prenom TEXT NOT NULL, whatsapp TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE, pays TEXT NOT NULL, ville TEXT NOT NULL, niveau TEXT NOT NULL,
    objectif TEXT NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL,
    completed_modules TEXT NOT NULL DEFAULT '[]', intermediate_modules TEXT NOT NULL DEFAULT '[]',
    advanced_modules TEXT NOT NULL DEFAULT '[]', beginner_passed INTEGER NOT NULL DEFAULT 0,
    intermediate_passed INTEGER NOT NULL DEFAULT 0, advanced_passed INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS quiz_results (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    level TEXT NOT NULL, score INTEGER NOT NULL, total INTEGER NOT NULL, percent INTEGER NOT NULL,
    passed INTEGER NOT NULL, created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS custom_courses (
    id TEXT PRIMARY KEY, level TEXT NOT NULL, title TEXT NOT NULL, desc TEXT NOT NULL,
    lesson_title TEXT NOT NULL, lesson_text TEXT NOT NULL, created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, user_id TEXT, message TEXT, created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_quiz_user ON quiz_results(user_id);
  CREATE INDEX IF NOT EXISTS idx_quiz_level ON quiz_results(level);
  CREATE INDEX IF NOT EXISTS idx_courses_level ON custom_courses(level);
`);

function id(){ return crypto.randomUUID(); }
function now(){ return new Date().toISOString(); }
function hashPassword(p,salt=crypto.randomBytes(16).toString("hex")){ return salt+":"+crypto.scryptSync(p,salt,64).toString("hex"); }
function checkPassword(p,stored){
  const [salt,h]=String(stored).split(":");
  if(!salt||!h)return false;
  const x=crypto.scryptSync(p,salt,64).toString("hex");
  const a=Buffer.from(x), b=Buffer.from(h);
  return a.length===b.length && crypto.timingSafeEqual(a,b);
}
function arr(v){ try{return JSON.parse(v||"[]")}catch{return[]} }
function rowToUser(r){ if(!r)return null; return {id:r.id,nom:r.nom,prenom:r.prenom,whatsapp:r.whatsapp,email:r.email,pays:r.pays,ville:r.ville,niveau:r.niveau,objectif:r.objectif,passwordHash:r.password_hash,createdAt:r.created_at,completedModules:arr(r.completed_modules),intermediateModules:arr(r.intermediate_modules),advancedModules:arr(r.advanced_modules),beginnerPassed:!!r.beginner_passed,intermediatePassed:!!r.intermediate_passed,advancedPassed:!!r.advanced_passed}; }
function publicUser(u){ const x={...u}; delete x.passwordHash; return x; }
function getUserById(uid){ return rowToUser(db.prepare("SELECT * FROM users WHERE id=?").get(uid)); }
function getUserByEmail(email){ return rowToUser(db.prepare("SELECT * FROM users WHERE lower(email)=lower(?)").get(email)); }
function updateUser(u){ db.prepare(`UPDATE users SET completed_modules=?, intermediate_modules=?, advanced_modules=?, beginner_passed=?, intermediate_passed=?, advanced_passed=? WHERE id=?`).run(JSON.stringify(u.completedModules||[]),JSON.stringify(u.intermediateModules||[]),JSON.stringify(u.advancedModules||[]),u.beginnerPassed?1:0,u.intermediatePassed?1:0,u.advancedPassed?1:0,u.id); }
function insertUser(u){ db.prepare(`INSERT INTO users(id,nom,prenom,whatsapp,email,pays,ville,niveau,objectif,password_hash,created_at,completed_modules,intermediate_modules,advanced_modules,beginner_passed,intermediate_passed,advanced_passed) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(u.id,u.nom,u.prenom,u.whatsapp,u.email,u.pays,u.ville,u.niveau,u.objectif,u.passwordHash,u.createdAt,JSON.stringify(u.completedModules),JSON.stringify(u.intermediateModules),JSON.stringify(u.advancedModules),0,0,0); }
function customCourses(){ return db.prepare("SELECT * FROM custom_courses ORDER BY created_at ASC").all().map(r=>({id:r.id,level:r.level,title:r.title,desc:r.desc,lessons:[[r.lesson_title,r.lesson_text]],createdAt:r.created_at})); }
function allCourses(){ const cc=customCourses(); return {beginner:[...courses,...cc.filter(c=>c.level==="beginner")],intermediate:[...intermediateCourses,...cc.filter(c=>c.level==="intermediate")],advanced:[...advancedCourses,...cc.filter(c=>c.level==="advanced")]}; }
function cookie(name,value,maxAge=86400*30){ const secure=process.env.NODE_ENV==="production"||process.env.COOKIE_SECURE==="1"; return `${name}=${encodeURIComponent(value)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${secure?"; Secure":""}`; }
function currentUser(req){ const c=req.headers.cookie||""; const m=c.match(/(?:^|;\s*)sid=([^;]+)/); const s=m&&sessions.get(decodeURIComponent(m[1])); return s?.userId?getUserById(s.userId):null; }
function isAdmin(req){ const c=req.headers.cookie||""; const m=c.match(/(?:^|;\s*)adminsid=([^;]+)/); const s=m&&sessions.get(decodeURIComponent(m[1])); return !!s?.admin; }
function send(res,status,data,headers={}){ const body=typeof data==="string"?data:JSON.stringify(data); res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","X-Content-Type-Options":"nosniff","X-Frame-Options":"SAMEORIGIN","Referrer-Policy":"strict-origin-when-cross-origin","Permissions-Policy":"camera=(), microphone=(), geolocation=()","Cache-Control":"no-store",...headers}); res.end(body); }
function body(req){ return new Promise((resolve,reject)=>{ let b=""; req.on("data",c=>{b+=c;if(b.length>1e6){reject(new Error("Payload too large"));req.destroy();}}); req.on("end",()=>{try{resolve(b?JSON.parse(b):{})}catch(e){reject(e)}}); req.on("error",reject); }); }
function limited(req,key,max=20,windowMs=60000){ const ip=String(req.headers["x-forwarded-for"]||req.socket.remoteAddress||"unknown").split(",")[0].trim(); const k=key+":"+ip; const t=Date.now(); const x=rate.get(k)||{n:0,t}; if(t-x.t>windowMs){x.n=0;x.t=t} x.n++; rate.set(k,x); return x.n<=max; }

// Importe automatiquement l'ancien data.json une seule fois dans SQLite.
function migrateLegacy(){
  if(!fs.existsSync(LEGACY_DATA))return;
  const marker=db.prepare("SELECT value FROM meta WHERE key='legacy_migrated'");
}

try { db.exec("CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)"); } catch(e) { console.error(e); process.exit(1); }
function migrateLegacyData(){
  const done=db.prepare("SELECT value FROM meta WHERE key='legacy_migrated'").get();
  if(done)return;
  if(!fs.existsSync(LEGACY_DATA)){ db.prepare("INSERT OR REPLACE INTO meta(key,value) VALUES('legacy_migrated','no-file')").run(); return; }
  try{
    const d=JSON.parse(fs.readFileSync(LEGACY_DATA,"utf8"));
    const tx=db.createSession?null:null;
    for(const u of (d.users||[])){
      if(!getUserById(u.id)) insertUser({...u,passwordHash:u.passwordHash||""});
      else updateUser(u);
    }
    for(const q of (d.quizResults||[])){
      db.prepare("INSERT OR IGNORE INTO quiz_results(id,user_id,level,score,total,percent,passed,created_at) VALUES(?,?,?,?,?,?,?,?)").run(q.id,q.userId,q.level,q.score,q.total,q.percent,q.passed?1:0,q.createdAt||now());
    }
    for(const c of (d.customCourses||[])){
      const l=c.lessons?.[0]||["Leçon",""];
      db.prepare("INSERT OR IGNORE INTO custom_courses(id,level,title,desc,lesson_title,lesson_text,created_at) VALUES(?,?,?,?,?,?,?)").run(c.id,c.level,c.title,c.desc||"",l[0]||"Leçon",l[1]||"",c.createdAt||now());
    }
    db.prepare("INSERT OR REPLACE INTO meta(key,value) VALUES('legacy_migrated',?)").run(now());
    console.log("Migration data.json → SQLite terminée.");
  }catch(e){ console.error("Migration legacy échouée:",e.message); throw e; }
}
migrateLegacyData();

const courses=[
 {id:"m1",title:"Découvrir le trading",desc:"Marchés, trading, investissement et fonctionnement général.",lessons:[
  ["Qu'est-ce que le trading ?","Le trading consiste à prendre des positions sur des instruments financiers selon un plan et un niveau de risque défini. Aucun résultat futur n'est garanti."],
  ["Trader et investir","Le trading vise généralement des opérations plus fréquentes, tandis que l'investissement s'inscrit souvent sur une durée plus longue. Les deux comportent des risques."]
 ]},
 {id:"m2",title:"Les marchés financiers",desc:"Forex, actions, indices, matières premières et crypto-actifs.",lessons:[
  ["Forex","Le Forex est le marché des devises. Une paire compare la valeur relative de deux monnaies."],
  ["Autres marchés","Actions, indices, matières premières et crypto-actifs ont des caractéristiques et des risques différents."]
 ]},
 {id:"m3",title:"Lire un graphique",desc:"Bougies, unités de temps, tendances et consolidations.",lessons:[
  ["Bougies japonaises","Une bougie représente notamment l'ouverture, le plus haut, le plus bas et la clôture d'une période."],
  ["Tendances","Une tendance décrit une direction générale des prix sur une période donnée; elle peut être haussière, baissière ou latérale."]
 ]},
 {id:"m4",title:"Analyse technique",desc:"Supports, résistances, tendances et cassures.",lessons:[
  ["Support et résistance","Ce sont des zones observées où le prix peut réagir. Elles ne constituent pas des garanties de mouvement futur."],
  ["Cassure","Une cassure correspond au franchissement d'une zone observée. Elle doit être interprétée avec le contexte et le risque."]
 ]},
 {id:"m5",title:"Gestion du risque",desc:"Stop Loss, Take Profit, risque par position et ratio.",lessons:[
  ["Risque par trade","Définir à l'avance une perte maximale acceptable aide à protéger le capital."],
  ["Stop Loss et Take Profit","Ils peuvent servir à planifier une sortie selon un scénario; ils ne garantissent pas le prix d'exécution exact."]
 ]},
 {id:"m6",title:"Psychologie du trader",desc:"Discipline, patience, FOMO et revenge trading.",lessons:[
  ["Discipline","Une méthode n'est utile que si ses règles sont appliquées de façon cohérente."],
  ["Émotions","Le FOMO et le revenge trading peuvent pousser à prendre des décisions impulsives. Le journal aide à repérer ces comportements."]
 ]},
 {id:"m7",title:"Construire son plan de trading",desc:"Entrée, invalidation, risque, sortie et journal.",lessons:[
  ["Plan","Un plan peut définir le marché, les conditions d'entrée, l'invalidation, le risque et les règles de sortie."],
  ["Journal","Documenter chaque décision permet d'analyser le processus et d'améliorer progressivement sa méthode."]
 ]}
];
const intermediateCourses=[
 {id:"i1",title:"Structure du marché",desc:"Sommets, creux, impulsions, corrections et contexte.",lessons:[["Structure", "Analyse les sommets et creux pour distinguer une structure haussière, baissière ou latérale."],["Impulsion et correction","Une impulsion est un mouvement directionnel; une correction est un mouvement opposé ou de respiration du marché."]] },
 {id:"i2",title:"Liquidité et zones clés",desc:"Zones de liquidité, niveaux importants et réactions du prix.",lessons:[["Liquidité", "La liquidité désigne notamment les zones où de nombreux ordres peuvent être présents; elle ne prédit pas à elle seule le prochain mouvement."],["Zones clés","Combine plusieurs éléments de contexte plutôt que de considérer un niveau isolé comme une certitude."]] },
 {id:"i3",title:"Price Action",desc:"Lecture du comportement du prix et confirmations.",lessons:[["Réaction du prix","Observe les rejets, clôtures et accélérations avec le contexte général."],["Confirmation","Une confirmation réduit certaines ambiguïtés mais ne supprime jamais le risque de perte."]] },
 {id:"i4",title:"Indicateurs techniques",desc:"Moyennes mobiles, RSI, volatilité et limites des indicateurs.",lessons:[["Moyennes mobiles","Elles peuvent aider à visualiser une tendance ou une dynamique, mais restent des outils retardés."],["RSI et volatilité","Le RSI et les mesures de volatilité servent à contextualiser le marché; ils ne donnent pas de garantie d'entrée ou de sortie."]] },
 {id:"i5",title:"Entrées et invalidation",desc:"Scénario, point d'entrée, invalidation et exécution.",lessons:[["Scénario","Avant une entrée, définis ce qui doit se produire et ce qui invaliderait ton idée."],["Exécution","Évite les entrées impulsives et respecte les règles définies avant le trade."]] },
 {id:"i6",title:"Gestion avancée du risque",desc:"Taille de position, risque fixe, séries de pertes et levier.",lessons:[["Taille de position","La taille doit découler du risque accepté et de la distance jusqu'à l'invalidation, pas d'une envie de gagner plus."],["Séries de pertes","Une série de pertes est possible même avec une méthode cohérente; réduis le risque si ton plan le prévoit et analyse ton journal."]] },
 {id:"i7",title:"Backtesting et statistiques",desc:"Échantillon, taux de réussite, ratio risque/rendement et journal statistique.",lessons:[["Backtesting","Teste des règles définies sur un historique suffisamment large et documente les hypothèses."],["Statistiques","Observe notamment fréquence, gains/pertes moyens, drawdown et stabilité; les résultats passés ne garantissent pas le futur."]] }
];
const intermediateQuestions=[
 ["Une structure haussière se caractérise généralement par…",["des sommets et creux globalement ascendants","des prix totalement immobiles","une garantie de hausse","une absence de corrections"],0],
 ["Une correction est…",["un mouvement de respiration ou opposé à l'impulsion dominante","une garantie de retournement","un profit assuré","un indicateur"],0],
 ["Pourquoi identifier des zones clés ?",["Pour contextualiser les réactions possibles du prix","Pour garantir une entrée","Pour supprimer le risque","Pour prédire chaque bougie"],0],
 ["Le Price Action consiste principalement à…",["analyser le comportement du prix et son contexte","suivre uniquement un indicateur","garantir un rendement","éviter les graphiques"],0],
 ["Une confirmation de setup…",["peut réduire certaines ambiguïtés sans supprimer le risque","garantit un trade gagnant","rend le Stop Loss inutile","supprime la volatilité"],0],
 ["Une moyenne mobile est notamment…",["un outil qui peut aider à visualiser la dynamique ou tendance","une garantie de direction","un ordre de marché","une protection du capital"],0],
 ["Le RSI doit être utilisé comme…",["un élément de contexte parmi d'autres","une garantie de retournement","un signal infaillible","un remplacement du plan"],0],
 ["Avant une entrée, il est utile de définir…",["le scénario et son invalidation","une promesse de gain","le nombre de followers","une certitude de résultat"],0],
 ["L'invalidation d'un scénario indique…",["la condition à partir de laquelle l'idée de trade n'est plus valide","un bénéfice garanti","une nouvelle stratégie obligatoire","un levier minimal"],0],
 ["La taille de position devrait principalement dépendre…",["du risque accepté et de la distance jusqu'à l'invalidation","de l'envie de gagner plus","du nombre de trades précédents","du nombre d'abonnés"],0],
 ["Le levier peut…",["amplifier les gains comme les pertes","supprimer les pertes","garantir un rendement","remplacer la gestion du risque"],0],
 ["Une série de pertes…",["peut arriver même avec une méthode cohérente","prouve toujours que la stratégie est inutile","doit être suivie d'un doublement des mises","garantit un prochain gain"],0],
 ["Le backtesting sert à…",["tester des règles sur des données historiques","garantir les résultats futurs","modifier les prix passés","supprimer le risque réel"],0],
 ["Un échantillon de backtesting trop petit peut…",["donner une vision peu fiable des performances","garantir une meilleure précision","supprimer les biais","rendre le marché prévisible"],0],
 ["Le drawdown mesure notamment…",["une baisse du capital depuis un précédent niveau de référence","le nombre de bougies","la vitesse d'internet","la taille du compte uniquement"],0],
 ["Un ratio risque/rendement compare…",["la perte potentielle au gain potentiel planifié","deux courtiers","deux unités de temps uniquement","le volume et le spread uniquement"],0],
 ["Pourquoi tenir des statistiques de trading ?",["Pour évaluer le processus avec des données plutôt qu'avec l'émotion","Pour garantir des profits","Pour supprimer les pertes","Pour prédire chaque trade"],0],
 ["Après plusieurs pertes, une démarche prudente est de…",["revoir le journal, le plan et les paramètres de risque","augmenter immédiatement le levier","supprimer l'invalidation","prendre davantage de trades"],0],
 ["Les résultats historiques d'une stratégie…",["ne garantissent pas ses résultats futurs","garantissent toujours les mêmes performances","suppriment le risque","remplacent l'apprentissage"],0],
 ["Le niveau Intermédiaire de Biso Trader vise surtout à…",["approfondir l'analyse, l'exécution et la gestion du risque","garantir un revenu","fournir des signaux infaillibles","supprimer toute perte"],0]
];
const questions=[
 ["Quel est l'objectif principal de la gestion du risque ?",["Augmenter chaque trade","Limiter les pertes potentielles et protéger le capital","Garantir un gain","Éviter tout trade"],1],
 ["Une tendance haussière correspond généralement à…",["des sommets et creux globalement ascendants","des prix toujours identiques","une absence de volatilité","une baisse continue"],0],
 ["Un Stop Loss sert principalement à…",["définir une perte maximale prévue sur une position","garantir un bénéfice","augmenter automatiquement la taille","supprimer les frais"],0],
 ["Une bougie japonaise permet notamment d'observer…",["l'ouverture, le plus haut, le plus bas et la clôture","uniquement le bénéfice","uniquement le volume annuel","la garantie du prochain prix"],0],
 ["Le FOMO désigne notamment…",["la peur de rater une opportunité et l'envie d'entrer impulsivement","un type de graphique","une commission","un indicateur"],0],
 ["Un support est généralement…",["une zone où le prix peut trouver une demande et réagir","une garantie de hausse","un ordre obligatoire","un compte bancaire"],0],
 ["Une résistance est généralement…",["une zone où le prix peut rencontrer une offre et réagir","une garantie de baisse","un type de monnaie","un moyen de paiement"],0],
 ["Le backtesting consiste à…",["tester une règle sur des données historiques","modifier le marché réel","garantir des profits","éviter toute analyse"],0],
 ["Pourquoi tenir un journal de trading ?",["Documenter les décisions et analyser le processus","Garantir des gains","Remplacer le Stop Loss","Supprimer la discipline"],0],
 ["Le revenge trading est…",["prendre des trades impulsifs pour tenter de récupérer rapidement une perte","une méthode de diversification","un type d'ordre","une technique de dessin"],0],
 ["Une unité de temps indique notamment…",["la durée représentée par chaque bougie","le montant du capital","le nom du courtier","le niveau de risque garanti"],0],
 ["Le Take Profit sert à…",["définir un niveau de sortie prévu pour prendre un gain","garantir qu'un trade sera gagnant","augmenter le levier","éviter toute perte"],0],
 ["Quelle affirmation est la plus prudente ?",["Aucune stratégie ne garantit un profit futur","Toute stratégie gagnante reste toujours gagnante","Le marché est prévisible avec certitude","Un quiz suffit pour devenir professionnel"],0],
 ["La discipline consiste notamment à…",["respecter son plan et ses règles","trader plus souvent","augmenter les mises après une perte","suivre toutes les rumeurs"],0],
 ["Une cassure de résistance signifie simplement que…",["le prix a franchi une zone de résistance observée","le marché garantit une hausse","le Stop Loss est inutile","le risque disparaît"],0],
 ["Pourquoi le levier mérite-t-il une attention particulière ?",["Il peut amplifier les gains comme les pertes","Il supprime le risque","Il garantit un rendement","Il remplace l'analyse"],0],
 ["Quel élément appartient à un plan de trading ?",["Conditions d'entrée et d'invalidation","Promesse de gain quotidien","Garantie de marché","Nombre de followers"],0],
 ["Après plusieurs pertes, la meilleure démarche pédagogique est de…",["revoir le plan, le risque et le journal","doubler immédiatement la taille","supprimer le Stop Loss","prendre plus de trades"],0],
 ["Le trading comporte-t-il un risque de perte ?",["Oui, et aucune performance future n'est garantie","Non, si l'on suit une formation","Non, avec un Stop Loss","Seulement pour les débutants"],0],
 ["Le rôle d'une formation Biso Trader est principalement de…",["développer des connaissances et une méthode de travail","garantir des revenus","fournir des signaux infaillibles","supprimer le risque"],0]
];

const advancedCourses=[
 {id:"a1",title:"Architecture d’une stratégie",desc:"Construire des règles précises, cohérentes et testables.",lessons:[["Règles de stratégie","Une stratégie doit définir le contexte, les conditions d’entrée, l’invalidation, la sortie et les conditions où aucun trade n’est pris."],["Checklist","Une checklist réduit les décisions improvisées : contexte, setup, risque, exécution et journalisation."]] },
 {id:"a2",title:"Probabilités et espérance",desc:"Comprendre l’espérance mathématique, le taux de réussite et le ratio gain/perte.",lessons:[["Espérance","Une méthode peut être positive même avec un taux de réussite inférieur à 50 % si ses gains moyens et ses pertes moyennes sont correctement équilibrés."],["Distribution des résultats","Analyse les séries de gains et pertes, la dispersion et les scénarios défavorables au lieu de regarder uniquement le résultat moyen."]] },
 {id:"a3",title:"Gestion du drawdown",desc:"Préserver le capital et définir des limites de risque globales.",lessons:[["Drawdown maximal","Le drawdown mesure une baisse depuis un sommet de référence. Un plan professionnel prévoit des limites et des réactions avant que la situation ne devienne émotionnelle."],["Réduction du risque","Après une période défavorable, une réduction planifiée de l’exposition peut être préférable à une augmentation impulsive du levier."]] },
 {id:"a4",title:"Exécution et coûts",desc:"Spread, slippage, liquidité, commissions et qualité d’exécution.",lessons:[["Coûts réels","Spread, commission et slippage peuvent modifier le résultat d’une stratégie, surtout lorsque les objectifs sont courts."],["Qualité d’exécution","Les résultats d’un backtest doivent intégrer des hypothèses réalistes de coûts et d’exécution pour éviter une surestimation des performances."]] },
 {id:"a5",title:"Backtesting robuste",desc:"Éviter le sur-ajustement et valider une méthode sur plusieurs périodes.",lessons:[["Overfitting","Une stratégie trop adaptée à un historique peut échouer hors échantillon. Plus de paramètres ne signifie pas automatiquement meilleure stratégie."],["Validation","Sépare les données d’apprentissage et de validation lorsque c’est possible, puis teste la robustesse sur différents contextes de marché."]] },
 {id:"a6",title:"Plan professionnel et journal avancé",desc:"Mettre en place un processus reproductible et mesurable.",lessons:[["Processus","Un trader professionnel cherche d’abord la qualité du processus : préparation, exécution, gestion et revue."],["Journal avancé","Ajoute contexte, capture du graphique, raison d’entrée, erreur éventuelle, risque prévu et résultat pour distinguer bonne décision et bon résultat."]] },
 {id:"a7",title:"Préparation au mentorat",desc:"Organiser son dossier de progression et ses objectifs professionnels.",lessons:[["Dossier de progression","Rassemble ton plan, tes statistiques, tes captures et tes principales erreurs récurrentes."],["Objectifs réalistes","Définis des objectifs d’apprentissage mesurables sans considérer un rendement futur comme garanti. Le mentorat sert à structurer le travail, pas à promettre des profits."]] }
];
const advancedQuestions=[
 ["Une stratégie professionnelle doit notamment définir…",["contexte, entrée, invalidation, sortie et règles d’absence de trade","uniquement un indicateur","une promesse de gain","un levier maximal"],0],
 ["L’espérance mathématique sert à…",["évaluer le résultat moyen attendu d’une série de trades selon les hypothèses de la méthode","garantir le prochain trade","prédire chaque bougie","supprimer les pertes"],0],
 ["Une méthode peut être positive avec moins de 50 % de réussite si…",["les gains moyens et pertes moyennes produisent une espérance favorable","elle utilise forcément un levier élevé","elle ne prend jamais de pertes","elle garantit chaque gain"],0],
 ["Le drawdown correspond notamment à…",["une baisse du capital depuis un sommet de référence","un nombre de trades gagnants","un type d’indicateur","un coût de courtage"],0],
 ["Face à un drawdown important, une approche professionnelle consiste d’abord à…",["suivre des limites prévues et analyser le processus","doubler immédiatement les positions","supprimer le Stop Loss","augmenter le levier"],0],
 ["Le spread est…",["un écart entre prix d’achat et prix de vente qui représente un coût de transaction","une garantie de liquidité","un objectif de gain","un type de graphique"],0],
 ["Le slippage peut…",["faire exécuter un ordre à un prix différent du prix attendu","garantir une meilleure entrée","supprimer les commissions","rendre le backtest inutile"],0],
 ["Pourquoi intégrer les coûts au backtesting ?",["Pour obtenir une estimation plus réaliste des performances","Pour garantir le futur","Pour supprimer la volatilité","Pour augmenter artificiellement le taux de réussite"],0],
 ["L’overfitting désigne notamment…",["une stratégie trop adaptée aux données historiques et moins robuste hors échantillon","une gestion prudente du risque","une réduction des paramètres","un type de Stop Loss"],0],
 ["Une bonne validation cherche notamment à…",["tester la robustesse sur des données ou contextes distincts de ceux utilisés pour construire la méthode","garantir les profits futurs","utiliser toujours plus de paramètres","éviter toute perte historique"],0],
 ["Un journal professionnel devrait permettre de distinguer…",["la qualité d’une décision et le résultat obtenu","les abonnés et les courtiers","les indicateurs et les réseaux sociaux","les gains garantis et les pertes garanties"],0],
 ["Une checklist sert principalement à…",["réduire les décisions improvisées et vérifier les règles avant l’exécution","augmenter le nombre de trades","garantir une entrée","supprimer le besoin d’analyse"],0],
 ["La diversification des scénarios doit être évaluée selon…",["le contexte, les corrélations et le risque global","uniquement le nombre d’actifs","le nombre d’abonnés","la couleur des graphiques"],0],
 ["Le risque global d’un portefeuille peut augmenter lorsque…",["plusieurs positions sont fortement corrélées","les positions sont toutes petites sans corrélation","le journal est bien tenu","le trader utilise une checklist"],0],
 ["Une réduction planifiée de l’exposition peut être utile…",["lorsque les règles de risque prévoient de réduire le risque dans certaines conditions","pour garantir un gain","pour supprimer les pertes","pour éviter tout backtesting"],0],
 ["Les résultats passés d’un backtest…",["ne garantissent pas les performances futures","garantissent les mêmes résultats","suppriment le risque réel","remplacent la validation"],0],
 ["Le rôle du mentorat professionnel devrait être de…",["structurer l’apprentissage, analyser le processus et améliorer la discipline","promettre des rendements","fournir des gains garantis","supprimer le risque de marché"],0],
 ["Avant de chercher la performance, un trader devrait prioriser…",["la préservation du capital et la maîtrise du processus","le levier maximal","la fréquence des trades","la taille maximale des positions"],0],
 ["Un objectif professionnel réaliste est plutôt…",["mesurer et améliorer des compétences et des processus","garantir un revenu mensuel","promettre un taux de réussite fixe","ne jamais connaître de pertes"],0],
 ["La validation du niveau Avancé de Biso Trader signifie principalement que l’apprenant…",["a démontré des connaissances avancées dans le parcours pédagogique, sans garantie de résultats financiers","est assuré de gagner de l’argent","peut supprimer toute gestion du risque","dispose d’un rendement futur garanti"],0]
];



async function api(req,res){
  const u=new URL(req.url,`http://${req.headers.host}`);
  try{
    if(req.method==="POST" && u.pathname==="/api/register"){
      if(!limited(req,"register",8,3600000)) return send(res,429,{error:"Trop de tentatives. Réessaie plus tard."});
      const b=await body(req); const required=["nom","prenom","whatsapp","email","pays","ville","niveau","objectif","password"];
      if(required.some(k=>!String(b[k]||"").trim())) return send(res,400,{error:"Tous les champs obligatoires doivent être remplis."});
      const email=String(b.email).trim().toLowerCase();
      if(!/^\S+@\S+\.\S+$/.test(email))return send(res,400,{error:"Adresse e-mail invalide."});
      if(String(b.password).length<8)return send(res,400,{error:"Le mot de passe doit contenir au moins 8 caractères."});
      if(getUserByEmail(email)) return send(res,409,{error:"Cet e-mail est déjà utilisé."});
      const user={id:id(),nom:String(b.nom).trim(),prenom:String(b.prenom).trim(),whatsapp:String(b.whatsapp).trim(),email,pays:String(b.pays).trim(),ville:String(b.ville).trim(),niveau:String(b.niveau).trim(),objectif:String(b.objectif).trim(),passwordHash:hashPassword(String(b.password)),createdAt:now(),completedModules:[],intermediateModules:[],advancedModules:[],beginnerPassed:false,intermediatePassed:false,advancedPassed:false};
      insertUser(user); const sid=id(); sessions.set(sid,{userId:user.id});
      return send(res,201,{user:publicUser(user)},{"Set-Cookie":cookie("sid",sid)});
    }
    if(req.method==="POST" && u.pathname==="/api/login"){
      if(!limited(req,"login",15,900000))return send(res,429,{error:"Trop de tentatives. Réessaie plus tard."});
      const b=await body(req); const user=getUserByEmail(String(b.email||""));
      if(!user||!checkPassword(String(b.password||""),user.passwordHash))return send(res,401,{error:"Identifiants incorrects."});
      const sid=id(); sessions.set(sid,{userId:user.id}); return send(res,200,{user:publicUser(user)},{"Set-Cookie":cookie("sid",sid)});
    }
    if(req.method==="POST" && u.pathname==="/api/logout"){ const c=req.headers.cookie||""; const m=c.match(/(?:^|;\s*)sid=([^;]+)/); if(m)sessions.delete(decodeURIComponent(m[1])); return send(res,200,{ok:true},{"Set-Cookie":cookie("sid","",0)}); }
    if(req.method==="POST" && u.pathname==="/api/admin/logout"){ const c=req.headers.cookie||""; const m=c.match(/(?:^|;\s*)adminsid=([^;]+)/); if(m)sessions.delete(decodeURIComponent(m[1])); return send(res,200,{ok:true},{"Set-Cookie":cookie("adminsid","",0)}); }
    if(req.method==="GET" && u.pathname==="/api/health"){ db.prepare("SELECT 1 AS ok").get(); return send(res,200,{ok:true,service:"biso-trader",database:"sqlite",node:process.versions.node}); }
    const user=currentUser(req);
    if(u.pathname==="/api/me"){ if(!user)return send(res,401,{error:"Non connecté"}); const sets=allCourses(); return send(res,200,{user:publicUser(user),courses:sets.beginner,intermediateCourses:sets.intermediate,advancedCourses:sets.advanced,hasIntermediate:!!user.beginnerPassed,hasAdvanced:!!user.intermediatePassed,professionalReady:!!user.advancedPassed}); }
    if(req.method==="POST" && u.pathname.startsWith("/api/modules/") && u.pathname.endsWith("/complete")){
      if(!user)return send(res,401,{error:"Non connecté"}); const mid=u.pathname.split("/")[3]; if(!allCourses().beginner.some(c=>c.id===mid))return send(res,404,{error:"Module introuvable"}); if(!user.completedModules.includes(mid))user.completedModules.push(mid); updateUser(user); return send(res,200,{completedModules:user.completedModules});
    }
    async function quiz(level, questions, prereq){
      if(!user)return send(res,401,{error:"Non connecté"}); if(prereq&&!prereq(user))return send(res,403,{error:"Niveau verrouillé."}); if(!limited(req,"quiz-"+level,30,3600000))return send(res,429,{error:"Trop de tentatives de quiz. Réessaie plus tard."});
      const b=await body(req); if(!Array.isArray(b.answers)||b.answers.length!==questions.length)return send(res,400,{error:"Réponses incomplètes."});
      let score=0; b.answers.forEach((a,i)=>{if(Number(a)===questions[i][2])score++}); const percent=Math.round(score/questions.length*100),passed=percent>=70;
      db.prepare("INSERT INTO quiz_results(id,user_id,level,score,total,percent,passed,created_at) VALUES(?,?,?,?,?,?,?,?)").run(id(),user.id,level,score,questions.length,percent,passed?1:0,now());
      if(level==="beginner"&&passed)user.beginnerPassed=true; if(level==="intermediate"&&passed)user.intermediatePassed=true; if(level==="advanced"&&passed)user.advancedPassed=true; updateUser(user);
      return send(res,200,{score,total:questions.length,percent,passed,nextLevel:passed?({beginner:"intermediate",intermediate:"advanced",advanced:"professional"}[level]):level});
    }
    if(req.method==="POST"&&u.pathname==="/api/quiz/beginner")return quiz("beginner",questions,null);
    if(req.method==="POST"&&u.pathname==="/api/quiz/intermediate")return quiz("intermediate",intermediateQuestions,u=>u.beginnerPassed);
    if(req.method==="POST"&&u.pathname==="/api/quiz/advanced")return quiz("advanced",advancedQuestions,u=>u.intermediatePassed);
    if(req.method==="POST"&&u.pathname.startsWith("/api/intermediate-modules/")&&u.pathname.endsWith("/complete")){ if(!user)return send(res,401,{error:"Non connecté"}); if(!user.beginnerPassed)return send(res,403,{error:"Réussis d'abord l'examen Débutant."}); const mid=u.pathname.split("/")[3]; if(!allCourses().intermediate.some(c=>c.id===mid))return send(res,404,{error:"Module introuvable"}); user.intermediateModules=user.intermediateModules||[]; if(!user.intermediateModules.includes(mid))user.intermediateModules.push(mid); updateUser(user); return send(res,200,{intermediateModules:user.intermediateModules}); }
    if(req.method==="POST"&&u.pathname.startsWith("/api/advanced-modules/")&&u.pathname.endsWith("/complete")){ if(!user)return send(res,401,{error:"Non connecté"}); if(!user.intermediatePassed)return send(res,403,{error:"Réussis d'abord l'examen Intermédiaire."}); const mid=u.pathname.split("/")[3]; if(!allCourses().advanced.some(c=>c.id===mid))return send(res,404,{error:"Module introuvable"}); user.advancedModules=user.advancedModules||[]; if(!user.advancedModules.includes(mid))user.advancedModules.push(mid); updateUser(user); return send(res,200,{advancedModules:user.advancedModules}); }
    if(req.method==="POST"&&u.pathname==="/api/ai"){
      if(!user)return send(res,401,{error:"Non connecté"}); const b=await body(req); const prompt=String(b.message||"").trim(); if(!prompt)return send(res,400,{error:"Message vide."});
      if(!process.env.OPENAI_API_KEY)return send(res,200,{answer:"Je suis l’assistant pédagogique de Biso Trader. Le moteur IA n’est pas encore connecté sur ce serveur."});
      const payload={model:process.env.OPENAI_MODEL||"gpt-5-mini",input:[{role:"system",content:[{type:"input_text",text:"Tu es l'assistant pédagogique de Biso Trader. Explique le trading de manière éducative, prudente et claire. Ne promets jamais de gains et ne donne pas d'instructions personnalisées d'investissement. Encourage la gestion du risque et l'apprentissage."}]},{role:"user",content:[{type:"input_text",text:prompt}]}]};
      const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Content-Type":"application/json","Authorization":"Bearer "+process.env.OPENAI_API_KEY},body:JSON.stringify(payload)}); const j=await r.json(); if(!r.ok)return send(res,502,{error:"Le service IA a retourné une erreur."}); return send(res,200,{answer:j.output_text||"Je n'ai pas pu générer une réponse."});
    }
    if(req.method==="POST"&&u.pathname==="/api/admin/login"){ if(!limited(req,"admin-login",10,900000))return send(res,429,{error:"Trop de tentatives."}); const b=await body(req); if(!process.env.ADMIN_KEY||String(b.key||"")!==String(process.env.ADMIN_KEY))return send(res,401,{error:"Clé administrateur incorrecte ou absente."}); const asid=id(); sessions.set(asid,{admin:true}); return send(res,200,{ok:true},{"Set-Cookie":cookie("adminsid",asid)}); }
    if(u.pathname.startsWith("/api/admin/")){ if(!isAdmin(req))return send(res,403,{error:"Accès administrateur requis."}); }
    if(req.method==="GET"&&u.pathname==="/api/admin/users"){ const rows=db.prepare("SELECT * FROM users ORDER BY created_at DESC").all(); return send(res,200,{users:rows.map(r=>publicUser(rowToUser(r)))}); }
    if(req.method==="GET"&&u.pathname==="/api/admin/quizzes"){ const rows=db.prepare("SELECT q.*,u.nom,u.prenom,u.email FROM quiz_results q JOIN users u ON u.id=q.user_id ORDER BY q.created_at DESC").all(); return send(res,200,{results:rows.map(q=>({...q,passed:!!q.passed}))}); }
    if(req.method==="GET"&&u.pathname==="/api/admin/courses"){ const sets=allCourses(); return send(res,200,{courses:[...sets.beginner.map(c=>({...c,level:c.level||"beginner",editable:c.id.startsWith("custom-")})),...sets.intermediate.map(c=>({...c,level:c.level||"intermediate",editable:c.id.startsWith("custom-")})),...sets.advanced.map(c=>({...c,level:c.level||"advanced",editable:c.id.startsWith("custom-")}))]}); }
    if(req.method==="POST"&&u.pathname==="/api/admin/course"){ const b=await body(req); const level=["beginner","intermediate","advanced"].includes(String(b.level))?String(b.level):"beginner"; if(!String(b.title||"").trim())return send(res,400,{error:"Titre obligatoire."}); const c={id:"custom-"+id(),level,title:String(b.title).trim(),desc:String(b.desc||"").trim(),lessons:[[String(b.lessonTitle||"Leçon").trim(),String(b.lessonText||"").trim()]],createdAt:now()}; const l=c.lessons[0]; db.prepare("INSERT INTO custom_courses(id,level,title,desc,lesson_title,lesson_text,created_at) VALUES(?,?,?,?,?,?,?)").run(c.id,c.level,c.title,c.desc,l[0],l[1],c.createdAt); return send(res,201,{course:c}); }
    if((req.method==="PUT"||req.method==="DELETE")&&u.pathname.startsWith("/api/admin/course/")){ const cid=decodeURIComponent(u.pathname.split("/").pop()); if(req.method==="DELETE"){const x=db.prepare("DELETE FROM custom_courses WHERE id=?").run(cid); if(!x.changes)return send(res,404,{error:"Formation personnalisée introuvable."}); return send(res,200,{ok:true});} const b=await body(req); const old=db.prepare("SELECT * FROM custom_courses WHERE id=?").get(cid); if(!old)return send(res,404,{error:"Formation personnalisée introuvable."}); const level=b.level&&["beginner","intermediate","advanced"].includes(b.level)?b.level:old.level; const title=b.title!==undefined?String(b.title).trim():old.title; const desc=b.desc!==undefined?String(b.desc).trim():old.desc; const lt=b.lessonTitle!==undefined?String(b.lessonTitle).trim():old.lesson_title; const lx=b.lessonText!==undefined?String(b.lessonText).trim():old.lesson_text; db.prepare("UPDATE custom_courses SET level=?,title=?,desc=?,lesson_title=?,lesson_text=? WHERE id=?").run(level,title,desc,lt,lx,cid); return send(res,200,{course:{id:cid,level,title,desc,lessons:[[lt,lx]],createdAt:old.created_at}}); }
    if(req.method==="GET"&&u.pathname==="/api/admin/stats"){ const users=db.prepare("SELECT COUNT(*) n FROM users").get().n; const quizAttempts=db.prepare("SELECT COUNT(*) n FROM quiz_results").get().n; const passed=db.prepare("SELECT COUNT(*) n FROM quiz_results WHERE passed=1").get().n; const levels={}; for(const l of ["beginner","intermediate","advanced"]){levels[l]={attempts:db.prepare("SELECT COUNT(*) n FROM quiz_results WHERE level=?").get(l).n,passed:db.prepare(`SELECT COUNT(*) n FROM users WHERE ${l}_passed=1`).get().n};} const customCourses=db.prepare("SELECT COUNT(*) n FROM custom_courses").get().n; return send(res,200,{users,quizAttempts,passed,levels,customCourses}); }
    return send(res,404,{error:"Route introuvable"});
  }catch(e){ console.error(e); return send(res,500,{error:"Erreur serveur."}); }
}

function staticFile(req,res){ let p=new URL(req.url,`http://${req.headers.host}`).pathname; if(p==="/")p="/index.html"; const file=path.normalize(path.join(PUBLIC,p)); if(!file.startsWith(PUBLIC))return send(res,403,{error:"Interdit"}); fs.readFile(file,(err,data)=>{if(err)return send(res,404,{error:"Fichier introuvable"}); const ext=path.extname(file); const types={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"application/javascript; charset=utf-8",".png":"image/png",".jpg":"image/jpeg",".svg":"image/svg+xml"}; res.writeHead(200,{"Content-Type":types[ext]||"application/octet-stream","Cache-Control":"no-cache","X-Content-Type-Options":"nosniff","X-Frame-Options":"SAMEORIGIN","Referrer-Policy":"strict-origin-when-cross-origin","Permissions-Policy":"camera=(), microphone=(), geolocation=()","Content-Security-Policy":"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self' https://api.openai.com; frame-ancestors 'self'"}); res.end(data);}); }

if(process.env.NODE_ENV==="production" && !String(process.env.ADMIN_KEY||"").trim()){ console.error("ADMIN_KEY est obligatoire en production."); process.exit(1); }
const server=http.createServer((req,res)=>req.url.startsWith("/api/")?api(req,res):staticFile(req,res));
server.listen(PORT,()=>console.log(`Biso Trader v6 sur http://localhost:${PORT} — SQLite: ${DB_FILE}`));
process.on("SIGINT",()=>{db.close();process.exit(0)});
process.on("SIGTERM",()=>{db.close();process.exit(0)});

# Biso Trader v6 — Base de données SQLite + préparation production

Biso Trader v6 conserve le parcours **Débutant → Intermédiaire → Avancé → Mentorat**, l'espace administrateur et les formations personnalisées, mais remplace `data.json` comme stockage principal par une **vraie base SQLite**.

## Nouveautés v6
- Base SQLite persistante : `biso-trader.sqlite` (ou `DB_FILE`).
- Tables séparées pour apprenants, résultats de quiz, formations personnalisées et messages.
- Index sur utilisateurs/quiz/formations.
- Migration automatique de l'ancien `data.json` lors du premier démarrage.
- `data.json` reste conservé comme sauvegarde source après migration.
- Rate limiting simple sur inscription, connexion, admin et examens.
- Cookies HttpOnly + SameSite, Secure automatiquement en production.
- En-têtes de sécurité HTTP.
- Endpoint `/api/health` pour les plateformes de déploiement.
- Déconnexion administrateur.
- Docker + volume persistant `/data`.
- `ADMIN_KEY` obligatoire en production.
- Les clés IA restent côté serveur.

## Important : Node.js
Cette version utilise `node:sqlite`, disponible avec **Node.js 22.5+**. Utilise Node.js 22 LTS ou plus récent.

## Lancer en local
```bash
cp .env.example .env
# adapte au minimum ADMIN_KEY et, en local, DB_FILE=./biso-trader.sqlite
npm start
```
Puis ouvre `http://localhost:3000`.

## Migration depuis v5
Place l'ancien `data.json` à côté de `server.js` avant le premier lancement. La v6 importe automatiquement :
- utilisateurs et progression ;
- résultats des examens ;
- formations personnalisées.

La migration est marquée dans la table `meta` pour éviter une seconde importation.

## Docker
```bash
cp .env.example .env
# Dans .env, mets une vraie ADMIN_KEY longue et DB_FILE=/data/biso-trader.sqlite
docker compose up -d --build
```
Le volume `biso_trader_data` conserve la base même si le conteneur est recréé.

Test santé : `GET /api/health`.

## Mise en ligne sécurisée
Pour une mise en ligne réelle :
1. Utilise un hébergeur avec HTTPS automatique et un **volume persistant** pour `/data`.
2. Configure `NODE_ENV=production`, `COOKIE_SECURE=1`, une `ADMIN_KEY` longue et aléatoire et `DB_FILE=/data/biso-trader.sqlite`.
3. Ne mets jamais `OPENAI_API_KEY` dans `public/` ou dans le navigateur.
4. Active les sauvegardes régulières du volume SQLite.
5. Configure un domaine et force HTTPS au niveau du proxy/hébergeur.
6. Ajoute une politique de confidentialité, une procédure de suppression de compte et une politique de conservation des données avant l'ouverture publique.
7. Pour plusieurs instances/serveurs simultanés, remplace SQLite par PostgreSQL : SQLite est très adapté à une application **monoinstance** avec volume persistant, mais n'est pas le choix idéal pour un déploiement horizontal.

## Sauvegarde SQLite
Arrête le service avant une copie simple du fichier, ou utilise un mécanisme de backup cohérent fourni par l'hébergeur. Conserve plusieurs versions de sauvegarde et teste régulièrement une restauration.

## Sécurité et limites
Cette version est mieux préparée pour la production mais reste un projet à auditer avant une ouverture publique. Il est recommandé d'ajouter :
- vérification e-mail et récupération de mot de passe ;
- MFA pour l'administration ;
- protection CSRF plus poussée si des actions sensibles sont ajoutées ;
- logs d'audit administrateur ;
- rotation/révocation des sessions persistantes ;
- monitoring et alertes ;
- sauvegardes chiffrées ;
- audit sécurité externe.

## Contenu financier
Biso Trader est présenté comme une plateforme pédagogique. Aucun contenu ne doit promettre un rendement ou présenter une performance future comme garantie.
